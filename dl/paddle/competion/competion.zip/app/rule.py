
from ..data import load_dataset
from sklearn.preprocessing import LabelEncoder
import pandas as pd
import numpy as np


def recommend(path:str):
    train_user, testa_user, train_goods, testa_goods = load_dataset(path)

    user_encode = LabelEncoder()
    user_encode.fit(list(train_user['user_id']) + list(train_user['user_id']))

    goods_encode = LabelEncoder()
    goods_encode.fit(list(train_user['goods_id']) + list(train_goods['goods_id']) + list(train_goods['goods_id']))

    print("user in train dataset: ", np.mean(testa_user['user_id'].isin(train_user['user_id'])))
    print("item in train dataset: ", np.mean(testa_goods['goods_id'].isin(train_goods['goods_id'])))
    print("unique user: ", train_user['user_id'].nunique())
    print("unique item: ", train_user['goods_id'].nunique())
    print("user desc: \n", train_user.describe().round(2))
    print("user count: \n", train_user['user_id'].value_counts())


    train_data = pd.merge(train_user.iloc[:], train_goods.iloc[:], on='goods_id')
    print("unqiue cate: ", train_data['cat_id'].nunique())
    print("unique brand: ", train_data['brandsn'].nunique())


    # 购买次数为0且加购次数不为0
    train_agg_feat = train_data.loc[
        (train_data['is_order'] == 0) & (train_data['is_addcart'] != 0) 
    ]

    train_agg_feat = train_agg_feat[train_agg_feat['user_id'].isin(testa_user['user_id'])]
    train_agg_feat = train_agg_feat[train_agg_feat['goods_id'].isin(testa_goods['goods_id'])]
    return train_agg_feat[['user_id', 'goods_id']]
